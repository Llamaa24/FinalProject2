package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class contactIcon extends AppCompatActivity {
    private ImageView image1;
    private ImageView image2;
    private ImageView image3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_contact_icon);

        image1 = findViewById(R.id.image_profile);
        image2 = findViewById(R.id.image_home);
        image3 = findViewById(R.id.image_contact);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main2), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        image1.setOnClickListener(v -> {
            // Handle profile image click
            Intent intent = new Intent(contactIcon.this, Profile.class);
            startActivity(intent);
        });

        image2.setOnClickListener(v -> {
            Intent intent = new Intent(contactIcon.this, FirstActivity.class);
            startActivity(intent);
        });

        image3.setOnClickListener(v -> {
            // Handle contact image click
            //Intent intent = new Intent(FirstActivity.this, contactIcon.class);
            //startActivity(intent);
        });
    }
}