package com.example.myapplication;
import java.util.ArrayList;
import java.util.List;

public class DataInitializer {
    public static List<Building> initializeData() {
        List<Building> buildings = new ArrayList<>();

        // Building 11
        Building building11 = new Building("Building 11", new ArrayList<>());
        Floor floor1B11 = new Floor(1, createClassroomSections("Class", 3, 28));
        Floor floor2B11 = new Floor(2, createClassroomSections("Lab", 102, 118));
        building11.getFloors().add(floor1B11);
        building11.getFloors().add(floor2B11);
        buildings.add(building11);

        // Building 17
        Building building17 = new Building("Building 17", new ArrayList<>());
        Floor floor1B17 = new Floor(1, createClassroomSections("Lab G", 2, 47));
        Floor floor2B17 = new Floor(2, createClassroomSections("Lab", 1037, 1071));
        Floor floor3B17 = new Floor(3, createClassroomSections("Class", 2004, 2039));
        Floor floor4B17 = new Floor(4, createClassroomSections("Class", 16, 18));
        building17.getFloors().add(floor1B17);
        building17.getFloors().add(floor2B17);
        building17.getFloors().add(floor3B17);
        building17.getFloors().add(floor4B17);
        buildings.add(building17);

        // Building 5
        Building building5 = new Building("Building 5", new ArrayList<>());
        Floor floor1 = new Floor(1, createSections1());

        Floor floor2 = new Floor(2, createSections2());
        Floor floor3 = new Floor(3, createSections3());

        building5.getFloors().add(floor1);
        building5.getFloors().add(floor2);
        building5.getFloors().add(floor3);
        buildings.add(building5);

        return buildings;
    }

    private static List<Section> createClassroomSections(String prefix, int start, int end) {
        List<Section> sections = new ArrayList<>();
        List<Classroom> classrooms = createClassrooms(prefix, start, end);
        sections.add(new Section("Main", classrooms));
        return sections;
    }

    private static List<Classroom> createClassrooms(String prefix, int start, int end) {
        List<Classroom> classrooms = new ArrayList<>();
        for (int i = start; i <= end; i++) {
            classrooms.add(new Classroom(prefix + i, "Available"));
        }
        return classrooms;
    }

    private static List<Section> createSections1() {
        List<Section> sections = new ArrayList<>();
        sections.add(new Section("A", createClassrooms("Class", 106, 109)));
        sections.add(new Section("B", createClassrooms("Class", 0, 0)));
        sections.add(new Section("C", createClassrooms("Class", 103, 112)));
        sections.add(new Section("D", createClassrooms("Class", 0, 0)));
        return sections;
    }


    private static List<Section> createSections2() {
        List<Section> sections = new ArrayList<>();
        sections.add(new Section("A", createClassrooms("Class", 203, 212)));
        sections.add(new Section("B", createClassrooms("Class", 203, 212)));
        sections.add(new Section("C", createClassrooms("Class", 203, 212)));
        sections.add(new Section("D", createClassrooms("Class", 203, 212)));
        return sections;}

    private static List<Section> createSections3() {
        List<Section> sections = new ArrayList<>();
        sections.add(new Section("A", createClassrooms("Class", 303, 312)));
        sections.add(new Section("B", createClassrooms("Class", 303, 312)));
        sections.add(new Section("C", createClassrooms("Class", 303, 312)));
        sections.add(new Section("D", createClassrooms("Class", 303, 312)));
        return sections;}
}








