package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "school.db";
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create tables
        String createTable = "CREATE TABLE bookings (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "date TEXT, " +
                "startTime TEXT, " +
                "endTime TEXT, " +
                "class TEXT, " +
                "building TEXT, " +
                "status TEXT)";
        db.execSQL(createTable);

        String createReportTable = "CREATE TABLE reports (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "building TEXT, " +
                "floor TEXT, " +
                "class TEXT, " +
                "problemDescription TEXT)";
        db.execSQL(createReportTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Upgrade database
        db.execSQL("DROP TABLE IF EXISTS bookings");
        db.execSQL("DROP TABLE IF EXISTS reports");
        onCreate(db);
    }

    public boolean isClassAvailable(String date, String startTime, String endTime, String className, String buildingName) {
        // Check if the class is available
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM bookings WHERE date = ? AND startTime = ? AND endTime = ? AND class = ? AND building = ?";
        Cursor cursor = db.rawQuery(query, new String[]{date, startTime, endTime, className, buildingName});
        boolean available = cursor.getCount() == 0;
        cursor.close();
        return available;
    }

    public void bookClass(String date, String startTime, String endTime, String className, String buildingName) {
        // Book the class
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("date", date);
        values.put("startTime", startTime);
        values.put("endTime", endTime);
        values.put("class", className);
        values.put("building", buildingName);
        values.put("status", "not available");
        db.insert("bookings", null, values);
    }

    public boolean isClassBooked(String date, String startTime, String endTime, String className, String buildingName) {
        // Check if the class is booked
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM bookings WHERE date = ? AND startTime = ? AND endTime = ? AND class = ? AND building = ?";
        Cursor cursor = db.rawQuery(query, new String[]{date, startTime, endTime, className, buildingName});
        boolean booked = cursor.getCount() > 0;
        cursor.close();
        return booked;
    }

    public void cancelBooking(String date, String startTime, String endTime, String className, String buildingName) {
        // Cancel the booking
        SQLiteDatabase db = this.getWritableDatabase();
        String whereClause = "date = ? AND startTime = ? AND endTime = ? AND class = ? AND building = ?";
        db.delete("bookings", whereClause, new String[]{date, startTime, endTime, className, buildingName});
    }

    public void submitReport(String building, String floor, String classNumber, String problemDescription) {
        // Submit the report
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("building", building);
        values.put("floor", floor);
        values.put("class", classNumber);
        values.put("problemDescription", problemDescription);
        db.insert("reports", null, values);
    }
}